<?php
/**
 * Plugin Name: Restaurant Posts Zigzag
 * Description: Displays restaurant posts in a zigzag layout for both default WordPress and Divi editor
 * Version: 1.4.5
 * Author: Thomas Scheiber
 * Text Domain: restaurant-posts-zigzag
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('RPZ_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RPZ_PLUGIN_URL', plugin_dir_url(__FILE__));

// Enqueue inline CSS and JS
function rpz_enqueue_scripts() {
    // CSS Styles
    $css = '/* Restaurant Posts Zigzag Layout Styles */
.rpz-zigzag-container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 30px 15px;
}
.rpz-zigzag-item {
    margin-bottom: 60px;
    clear: both;
    overflow: hidden;
}
.rpz-item-inner {
    display: flex !important;
    flex-wrap: wrap !important;
    align-items: center !important;
    justify-content: space-between !important;
}
/* Left layout (image left, content right) */
.rpz-item-left .rpz-item-inner {
    flex-direction: row !important;
}
/* Right layout (content left, image right) */
.rpz-item-right .rpz-item-inner {
    flex-direction: row-reverse !important;
}
.rpz-image {
    flex: 0 0 48% !important;
    max-width: 48% !important;
    overflow: hidden;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    min-height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.rpz-no-image {
    width: 100%;
    height: 100%;
    min-height: 200px;
    background-color: #f5f5f5;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.rpz-no-image:after {
    content: "No Image";
    color: #999;
    font-style: italic;
}
.rpz-image:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}
.rpz-image img {
    width: 100%;
    height: auto;
    display: block;
    transition: transform 0.5s ease;
}
.rpz-image:hover img {
    transform: scale(1.05);
}
.rpz-content {
    flex: 0 0 48% !important;
    max-width: 48% !important;
    padding: 20px;
}
.rpz-title {
    font-size: 24px;
    margin-bottom: 15px;
    font-weight: 600;
}
.rpz-title a {
    color: #333;
    text-decoration: none;
    transition: color 0.3s ease;
}
.rpz-title a:hover {
    color: #0073aa;
}
.rpz-excerpt {
    font-size: 16px;
    line-height: 1.6;
    color: #666;
}
.rpz-excerpt p {
    margin-bottom: 1em;
}
.rpz-excerpt strong, 
.rpz-excerpt b {
    font-weight: 700;
    color: #333;
}
.rpz-excerpt a {
    color: #0073aa;
    text-decoration: underline;
}
.rpz-excerpt a:hover {
    color: #005177;
}
.rpz-excerpt em,
.rpz-excerpt i {
    font-style: italic;
}
.rpz-excerpt br {
    display: block;
    content: "";
    margin-top: 10px;
}
/* Divi-specific overrides */
.et_pb_module .rpz-item-inner {
    display: flex !important;
    flex-wrap: wrap !important;
}
.et_pb_module .rpz-item-left .rpz-item-inner {
    flex-direction: row !important;
}
.et_pb_module .rpz-item-right .rpz-item-inner {
    flex-direction: row-reverse !important;
}
.et_pb_module .rpz-image,
.et_pb_module .rpz-content {
    width: 48% !important;
    max-width: 48% !important;
    float: none !important;
}
/* Responsive styles */
@media only screen and (max-width: 768px) {
    .rpz-item-left .rpz-item-inner,
    .rpz-item-right .rpz-item-inner,
    .et_pb_module .rpz-item-inner {
        flex-direction: column !important;
    }
    .rpz-image,
    .rpz-content,
    .et_pb_module .rpz-image,
    .et_pb_module .rpz-content {
        flex: 0 0 100% !important;
        max-width: 100% !important;
        width: 100% !important;
    }
    .rpz-image,
    .et_pb_module .rpz-image {
        margin-bottom: 20px;
    }
}
@media (prefers-reduced-motion: reduce) {
    .rpz-image, .rpz-image img, .rpz-title a { transition: none; }
    .rpz-image:hover, .rpz-image:hover img { transform: none; }
}';

    // Inline CSS
    wp_register_style('rpz-inline-style', false);
    wp_enqueue_style('rpz-inline-style');
    wp_add_inline_style('rpz-inline-style', $css);
    

}
add_action('wp_enqueue_scripts', 'rpz_enqueue_scripts');

/**
 * Get formatted content preserving HTML formatting
 * 
 * @param int $post_id The post ID
 * @param int $excerpt_length Optional excerpt length
 * @return string Formatted content with preserved HTML
 */
function rpz_get_formatted_content($post_id, $excerpt_length = 0) {
    $content = '';

    if (has_excerpt($post_id)) {
        $content = get_post_field('post_excerpt', $post_id);
        $content = wpautop($content);
    } else {
        $content = get_post_field('post_content', $post_id);

        if (strpos($content, '<!--more-->') !== false) {
            $content = explode('<!--more-->', $content)[0];
        }

        // Render Gutenberg blocks and shortcodes the same way as the single post view.
        $content = apply_filters('the_content', $content);
    }

    $allowed_html = array(
        'strong' => array(),
        'b'      => array(),
        'em'     => array(),
        'i'      => array(),
        'br'     => array(),
        'p'      => array(
            'style' => array(),
            'class' => array(),
        ),
        'ul'     => array(),
        'ol'     => array(),
        'li'     => array(),
        'a'      => array(
            'href'   => array(),
            'title'  => array(),
            'class'  => array(),
            'target' => array(),
            'rel'    => array(),
        ),
        'span'   => array(
            'style' => array(),
            'class' => array(),
        ),
        'div'    => array(
            'style' => array(),
            'class' => array(),
        ),
    );

    $content = wp_kses($content, $allowed_html);

    if ($excerpt_length > 0 && !has_excerpt($post_id)) {
        $content = rpz_truncate_html($content, $excerpt_length);
    }

    return $content;
}

/**
 * Truncate HTML content while preserving HTML tags
 * 
 * @param string $html The HTML content to truncate
 * @param int $limit Word limit
 * @param string $ellipsis Text to append when truncated
 * @return string Truncated HTML
 */
function rpz_truncate_html($html, $limit, $ellipsis = '...') {
    if ($limit <= 0) {
        return $html;
    }

    $words = preg_split('/\s+/u', wp_strip_all_tags($html), -1, PREG_SPLIT_NO_EMPTY);

    if (count($words) <= $limit) {
        return $html;
    }

    // Keep whole paragraphs so bold text, links, and line breaks stay intact.
    if (preg_match_all('/<p[^>]*>.*?<\/p>/is', $html, $matches) && !empty($matches[0])) {
        $result = '';
        $word_count = 0;

        foreach ($matches[0] as $paragraph) {
            $paragraph_words = preg_split('/\s+/u', wp_strip_all_tags($paragraph), -1, PREG_SPLIT_NO_EMPTY);

            if ($word_count > 0 && ($word_count + count($paragraph_words)) > $limit) {
                break;
            }

            $result .= $paragraph;
            $word_count += count($paragraph_words);
        }

        if (!empty($result)) {
            if ($word_count < count($words)) {
                $result = preg_replace('/<\/p>\s*$/i', ' ' . esc_html($ellipsis) . '</p>', $result, 1);
            }
            return $result;
        }
    }

    return $html;
}

// Register shortcode [restaurant_zigzag]
function rpz_restaurant_zigzag_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'count' => 6, // Default number of posts to display
            'category' => '', // Optional category filter
        ),
        $atts,
        'restaurant_zigzag'
    );
    
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => intval($atts['count']),
        'orderby' => 'date',
        'order' => 'DESC',
    );
    
    // Add category filter if specified
    if (!empty($atts['category'])) {
        $args['category_name'] = $atts['category'];
    }
    
    $posts_query = new WP_Query($args);
    $output = '';
    
    if ($posts_query->have_posts()) {
        $output .= '<div class="rpz-zigzag-container">';
        $count = 0;
        
        while ($posts_query->have_posts()) {
            $posts_query->the_post();
            $post_id = get_the_ID();
            $post_title = get_the_title();
            $post_content = rpz_get_formatted_content($post_id);
            $post_image = get_the_post_thumbnail_url($post_id, 'large');
            $post_link = get_permalink();
            
            // Alternate layout based on even/odd count
            $layout_class = ($count % 2 == 0) ? 'rpz-item-left' : 'rpz-item-right';
            
            $output .= '<div class="rpz-zigzag-item ' . $layout_class . '">';
            $output .= '<div class="rpz-item-inner">';
            
            // Create image HTML
            $image_html = '<div class="rpz-image">';
            if ($post_image) {
                $image_html .= '<a href="' . esc_url($post_link) . '"><img src="' . esc_url($post_image) . '" alt="' . esc_attr($post_title) . '"></a>';
            } else {
                // Placeholder if no image
                $image_html .= '<div class="rpz-no-image"></div>';
            }
            $image_html .= '</div>';
            
            // Create content HTML
            $content_html = '<div class="rpz-content">';
            $content_html .= '<h3 class="rpz-title"><a href="' . esc_url($post_link) . '">' . esc_html($post_title) . '</a></h3>';
            $content_html .= '<div class="rpz-excerpt">' . $post_content . '</div>';
            $content_html .= '</div>';
            
            // Always add both parts - they will be ordered by CSS based on the item class
            $output .= $image_html . $content_html;
            
            $output .= '</div>'; // End item-inner
            $output .= '</div>'; // End zigzag-item
            $count++;
        }
        
        $output .= '</div>'; // End container
        wp_reset_postdata();
    } else {
        $output = '<p>' . __('No posts found.', 'restaurant-posts-zigzag') . '</p>';
    }
    
    return $output;
}
add_shortcode('restaurant_zigzag', 'rpz_restaurant_zigzag_shortcode');

// Add Divi Builder compatibility - register as a Divi module
function rpz_initialize_divi_extension() {
    if (class_exists('ET_Builder_Module')) {
        class RPZ_Divi_Module extends ET_Builder_Module {
            function init() {
                $this->name = esc_html__('Restaurant ZigZag', 'restaurant-posts-zigzag');
                $this->plural = esc_html__('Restaurant ZigZag', 'restaurant-posts-zigzag');
                $this->slug = 'rpz_divi_module';
                $this->vb_support = 'on';
                $this->icon = 'j';
                
                // Define all fields that will be used
                $this->fields_defaults = array(
                    'posts_count' => array('6', 'add_default_setting'),
                    'category' => array('', 'add_default_setting'),
                );
                
                // Add custom CSS to fix Divi conflicts
                add_action('wp_footer', array($this, 'add_custom_divi_fixes'));
            }
            
            // Add custom CSS fixes for Divi
            function add_custom_divi_fixes() {
                if (et_core_is_fb_enabled()) {
                    echo '<style>
                    .et-fb-app-frame .rpz-item-inner {
                        display: flex !important;
                        flex-wrap: wrap !important;
                    }
                    .et-fb-app-frame .rpz-item-left .rpz-item-inner {
                        flex-direction: row !important;
                    }
                    .et-fb-app-frame .rpz-item-right .rpz-item-inner {
                        flex-direction: row-reverse !important;
                    }
                    .et-fb-app-frame .rpz-image,
                    .et-fb-app-frame .rpz-content {
                        width: 48% !important;
                        max-width: 48% !important;
                        float: none !important;
                    }
                    @media only screen and (max-width: 768px) {
                        .et-fb-app-frame .rpz-item-inner {
                            flex-direction: column !important;
                        }
                        .et-fb-app-frame .rpz-image,
                        .et-fb-app-frame .rpz-content {
                            width: 100% !important;
                            max-width: 100% !important;
                        }
                    }
                    </style>';
                }
            }
            
            function get_fields() {
                return array(
                    'posts_count' => array(
                        'label' => esc_html__('Number of Posts', 'restaurant-posts-zigzag'),
                        'type' => 'text',
                        'option_category' => 'basic_option',
                        'description' => esc_html__('Control how many posts to display.', 'restaurant-posts-zigzag'),
                        'default' => '6',
                        'toggle_slug' => 'main_content',
                    ),
                    'category' => array(
                        'label' => esc_html__('Category', 'restaurant-posts-zigzag'),
                        'type' => 'text',
                        'option_category' => 'basic_option',
                        'description' => esc_html__('Enter a category slug to filter posts (optional).', 'restaurant-posts-zigzag'),
                        'toggle_slug' => 'main_content',
                    ),
                );
            }
            
            function get_advanced_fields_config() {
                return array(
                    'fonts' => array(
                        'title' => array(
                            'label' => esc_html__('Title', 'restaurant-posts-zigzag'),
                            'css' => array(
                                'main' => '%%order_class%% .rpz-title',
                                'important' => 'all',
                            ),
                            'font_size' => array(
                                'default' => '24px',
                            ),
                            'line_height' => array(
                                'default' => '1.3em',
                            ),
                        ),
                        'content' => array(
                            'label' => esc_html__('Content', 'restaurant-posts-zigzag'),
                            'css' => array(
                                'main' => '%%order_class%% .rpz-excerpt',
                                'important' => 'all',
                            ),
                            'font_size' => array(
                                'default' => '16px',
                            ),
                            'line_height' => array(
                                'default' => '1.6em',
                            ),
                        ),
                    ),
                    'margin_padding' => array(
                        'css' => array(
                            'important' => 'all',
                        ),
                    ),
                    'borders' => array(
                        'default' => array(
                            'css' => array(
                                'main' => array(
                                    'border_radii' => '%%order_class%% .rpz-image',
                                    'border_styles' => '%%order_class%% .rpz-image',
                                ),
                            ),
                        ),
                    ),
                    'box_shadow' => array(
                        'default' => array(
                            'css' => array(
                                'main' => '%%order_class%% .rpz-image',
                                'important' => 'all',
                            ),
                        ),
                    ),
                );
            }
            
            function render($attrs, $content = null, $render_slug) {
                $posts_count = $this->props['posts_count'];
                $category = $this->props['category'];
                
                $shortcode = '[restaurant_zigzag count="' . esc_attr($posts_count) . '" category="' . esc_attr($category) . '"]';
                
                return do_shortcode($shortcode);
            }
        }
        
        new RPZ_Divi_Module();
    }
}
add_action('et_builder_ready', 'rpz_initialize_divi_extension'); 