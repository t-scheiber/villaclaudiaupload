<?php
/**
 * Plugin Name: Villa Claudia Document Upload
 * Description: Integrates with MotoPress Hotel Booking to provide document upload functionality
 * Version: 1.7.6
 * Author: Thomas Scheiber
 * Text Domain: villa-claudia-docs
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/workflow.php';

class Villa_Claudia_Docs {
    use Villa_Claudia_Workflow;
    private $api_key;
    private $env_config = null;
    
    public function __construct() {
        // Initialize the plugin
        add_action('init', array($this, 'init'));
        add_filter('cron_schedules', array($this, 'calendar_schedules'));
        add_action('mphb_ical_auto_sync_parameters_fields', array($this, 'calendar_interval_field'));
        add_action('plugins_loaded', array($this, 'ensure_calendar_schedule'));
        
        // Configure SMTP
        add_action('phpmailer_init', array($this, 'configure_smtp'));
        
        // Register REST API endpoints
        add_action('rest_api_init', array($this, 'register_api_endpoints'));
        add_filter('rest_post_dispatch', array($this, 'private_rest_response'), 10, 3);
        
        // Add settings page
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // Add a meta box to the booking edit screen
        add_action('add_meta_boxes', array($this, 'add_documents_meta_box'));
        
        // Add AJAX handlers
        add_action('wp_ajax_villa_claudia_view_document', array($this, 'ajax_view_document'));
        
        // Add handler for updating document status
        add_action('admin_init', array($this, 'handle_document_status_update'));
        
        // Add handler for test email
        add_action('admin_init', array($this, 'handle_test_email'));
        
        // Add handler for sending documents to city
        add_action('wp_ajax_villa_claudia_send_to_city', array($this, 'handle_send_to_city'));
        
        // Add this new method to the class
        add_action('wp_ajax_villa_claudia_get_booking_docs', array($this, 'ajax_get_booking_docs'));
        
        // Add new handler for retrieving booking dates
        add_action('wp_ajax_villa_claudia_get_booking_dates', array($this, 'ajax_get_booking_dates'));
    }

    public function calendar_schedules($schedules) {
        $schedules['vc_five_minutes'] = array('interval' => 300, 'display' => 'Every five minutes');
        return $schedules;
    }

    public function ensure_calendar_schedule() {
        // MotoPress can initialize before this plugin registers its custom interval.
        if (function_exists('MPHB') && get_option('mphb_ical_auto_sync_enable') &&
            get_option('mphb_ical_auto_sync_interval') === 'vc_five_minutes' &&
            !wp_next_scheduled('mphb_cron_ical_auto_synchronization')) {
            MPHB()->cronManager()->rescheduleAutoSynchronizationCrons();
        }
    }

    public function calendar_interval_field($group) {
        $name = 'mphb_ical_auto_sync_interval';
        $index = $group->getIndexByName($name);
        if ($index < 0) { return; }
        $field = $group->getFieldByName($name);
        $replacement = \MPHB\Admin\Fields\FieldFactory::create($name, array(
            'type' => 'select', 'default' => $field->getDefault(),
            'label' => __('Interval', 'motopress-hotel-booking'),
            'list' => array('vc_five_minutes' => __('Every five minutes', 'villa-claudia-docs')) + $field->getList(),
        ));
        $replacement->setValue($field->getValue());
        $group->insertField($replacement, $index);
    }

    private function get_config_value($option_name, $env_keys = array(), $default = '') {
        foreach ($env_keys as $env_key) {
            $value = $this->get_env_value($env_key);
            if ($value !== null && $value !== '') {
                return $value;
            }
        }

        $option_value = get_option($option_name, null);
        if ($option_value !== null && $option_value !== '') {
            return $option_value;
        }

        return $default;
    }

    private function get_env_value($key) {
        $value = getenv($key);
        if ($value !== false && $value !== '') {
            return $value;
        }

        if (isset($_ENV[$key]) && $_ENV[$key] !== '') {
            return $_ENV[$key];
        }

        if (isset($_SERVER[$key]) && $_SERVER[$key] !== '') {
            return $_SERVER[$key];
        }

        $config = $this->load_env_config();
        if (isset($config[$key]) && $config[$key] !== '') {
            return $config[$key];
        }

        return null;
    }

    private function load_env_config() {
        if ($this->env_config !== null) {
            return $this->env_config;
        }

        $this->env_config = array();
        $paths = array_filter(array(
            getenv('VILLA_CLAUDIA_DOCS_ENV_FILE'),
            (defined('WP_CONTENT_DIR') ? dirname(WP_CONTENT_DIR) : '') . '/villa-claudia-docs.env',
            (defined('ABSPATH') ? dirname(ABSPATH) : '') . '/villa-claudia-docs.env',
            rtrim(getenv('HOME') ?: '', '/\\') . '/.villa-claudia-docs.env',
        ));

        foreach ($paths as $path) {
            if (!is_readable($path)) {
                continue;
            }

            $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if ($lines === false) {
                continue;
            }

            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || strpos($line, '#') === 0 || strpos($line, '=') === false) {
                    continue;
                }

                list($name, $value) = array_map('trim', explode('=', $line, 2));
                $this->env_config[$name] = trim($value, "\"'");
            }

            break;
        }

        return $this->env_config;
    }
    
    public function init() {
        $this->api_key = $this->get_config_value(
            'villa_claudia_api_key',
            array('VILLA_CLAUDIA_API_KEY', 'WORDPRESS_API_KEY'),
            ''
        );

        if (empty($this->api_key)) {
            // Generate a secure random API key if none exists
            $this->api_key = wp_generate_password(32, false);
            update_option('villa_claudia_api_key', $this->api_key);
        }
    }
    
    /**
     * Get or generate a secure booking ID for a booking
     */
    public function register_api_endpoints() {
        foreach (array('claim' => 'claim_reminder', 'complete' => 'complete_reminder') as $path => $callback) {
            register_rest_route('villa-claudia/v1', '/reminders/' . $path, array(
                'methods' => 'POST', 'callback' => array($this, $callback),
                'permission_callback' => array($this, 'validate_api_key')
            ));
        }
        
        register_rest_route('villa-claudia/v1', '/booking/(?P<id>\w+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_booking_data'),
            'permission_callback' => array($this, 'validate_api_key')
        ));
        
        // Add endpoint to get booking by secure ID
        register_rest_route('villa-claudia/v1', '/secure-booking/(?P<secure_id>\w+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_booking_by_secure_id'),
            'permission_callback' => array($this, 'validate_api_key')
        ));
        
        register_rest_route('villa-claudia/v1', '/bookings/upcoming', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_upcoming_bookings'),
            'permission_callback' => array($this, 'validate_api_key')
        ));
        
        register_rest_route('villa-claudia/v1', '/has-documents/(?P<id>\w+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'check_documents_exist'),
            'permission_callback' => array($this, 'validate_api_key')
        ));
        
        register_rest_route('villa-claudia/v1', '/upload-documents', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_document_upload'),
            'permission_callback' => array($this, 'validate_api_key')
        ));
        
        // Simple ping endpoint to check if API is working
        register_rest_route('villa-claudia/v1', '/ping', array(
            'methods' => 'GET',
            'callback' => array($this, 'ping'),
            'permission_callback' => array($this, 'validate_api_key')
        ));
    }
    
    public function validate_api_key($request) {
        $api_key = $request->get_header('x-api-key');
        return is_string($api_key) && is_string($this->api_key) && $this->api_key !== '' && hash_equals($this->api_key, $api_key);
    }
    
    public function get_booking_data($request) {
        $booking_id = $request->get_param('id');
        

        
        // First try to get the booking as a post
        $booking_post = get_post($booking_id);
        

        
        if (!$booking_post || $booking_post->post_type !== 'mphb_booking') {
            // If not found directly, try to find it in MotoPress tables
            global $wpdb;
            
            // Try to find by ID in the mphb custom tables
            $mphb_booking_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} 
                 WHERE meta_key = 'mphb_booking_id' 
                 AND meta_value = %s",
                $booking_id
            ));
            
            if ($mphb_booking_id) {
                $booking_post = get_post($mphb_booking_id);
            }
            
            if (!$booking_post || $booking_post->post_type !== 'mphb_booking') {
                return new WP_Error('no_booking', 'Booking not found', array('status' => 404));
            }
        }
        
        // Get booking details from post meta
        $check_in_date = get_post_meta($booking_post->ID, 'mphb_check_in_date', true);
        $check_out_date = get_post_meta($booking_post->ID, 'mphb_check_out_date', true);
        $customer_email = get_post_meta($booking_post->ID, 'mphb_email', true);
        
        // Try multiple approaches to get guest name
        $guest_info = get_post_meta($booking_post->ID, 'mphb_guest_info', true);
        $first_name = '';
        $last_name = '';
        
        // Check if guest_info is an array with the expected keys
        if (is_array($guest_info) && isset($guest_info['first_name'])) {
            $first_name = $guest_info['first_name'];
            $last_name = isset($guest_info['last_name']) ? $guest_info['last_name'] : '';
        } else {
            // Fallback to direct meta fields
            $first_name = get_post_meta($booking_post->ID, 'mphb_first_name', true);
            $last_name = get_post_meta($booking_post->ID, 'mphb_last_name', true);
        }
        
        $guest_name = trim($first_name . ' ' . $last_name);
        if (empty($guest_name)) {
            $guest_name = 'Guest'; // Default if we can't find a name
        }
        
        // Format response
        return array(
            'bookingId' => $booking_post->ID,
            'checkInDate' => $check_in_date,
            'checkOutDate' => $check_out_date,
            'guestName' => $guest_name,
            'guestEmail' => $customer_email,
            'status' => $booking_post->post_status
        );
    }
    
    /**
     * Get upcoming bookings for the next 14 days
     */
    public function get_upcoming_bookings() {
        global $wpdb;
        
        $today = current_time('Y-m-d');
        $two_weeks_later = (new DateTimeImmutable('today', wp_timezone()))->modify('+14 days')->format('Y-m-d');
        
        // Query upcoming bookings in the next 14 days
        $query = $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE 
            post_type = 'mphb_booking' AND 
            post_status = 'confirmed' AND 
            ID IN (
                SELECT post_id FROM {$wpdb->postmeta} 
                WHERE meta_key IN ('mphb_check_in_date', '_mphb_check_in_date') 
                AND meta_value BETWEEN %s AND %s
            )",
            $today, $two_weeks_later
        );
        
        $upcoming_booking_ids = $wpdb->get_col($query);
        
        if (empty($upcoming_booking_ids)) {
            return array();
        }
        
        $bookings = array();
        foreach ($upcoming_booking_ids as $booking_id) {
            // Create a fake request object to reuse the get_booking_data method
            $request = new WP_REST_Request('GET', '/villa-claudia/v1/booking/' . $booking_id);
            $request->set_param('id', $booking_id);
            
            $booking_data = $this->get_booking_data($request);
            
            // Skip if there was an error
            if (is_wp_error($booking_data)) {
                continue;
            }
            
            $booking_data['hasUploadedDocuments'] = $this->has_stored_documents($booking_id);
            $booking_data['reminderSent'] = get_post_meta($booking_id, 'villa_claudia_reminder_sent_for', true) === $this->booking_fingerprint($booking_id);
            $bookings[] = $booking_data;
        }
        
        return $bookings;
    }
    
    public function add_admin_menu() {
        add_submenu_page(
            'options-general.php',
            'Villa Claudia Documents',
            'Villa Claudia Docs',
            'manage_options',
            'villa-claudia-docs',
            array($this, 'admin_page')
        );
        
        // Add new Documents Upload admin page
        add_menu_page(
            'Document Uploads',
            'Document Uploads',
            'manage_options',
            'document-uploads',
            array($this, 'document_uploads_page'),
            'dashicons-media-document',
            30
        );

        // Add new Send to City admin page
        add_submenu_page(
            'document-uploads',
            'Send Documents to City',
            'Send to City',
            'manage_options',
            'send-to-city',
            array($this, 'send_to_city_page')
        );
    }
    
    public function register_settings() {
        register_setting('villa_claudia_settings', 'villa_claudia_api_key');
        register_setting('villa_claudia_settings', 'villa_claudia_city_email');
        register_setting('villa_claudia_settings', 'villa_claudia_smtp_password');
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h2>Villa Claudia Document Upload Settings</h2>
            <form method="post" action="options.php">
                <?php settings_fields('villa_claudia_settings'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">API Key</th>
                        <td>
                            <input type="text" style="width: 320px;" 
                                   name="villa_claudia_api_key" 
                                   value="<?php echo esc_attr(get_option('villa_claudia_api_key')); ?>" />
                            <p class="description">This key is used to authenticate API requests from the document upload application.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">City Email Address</th>
                        <td>
                            <input type="email" style="width: 320px;" 
                                   name="villa_claudia_city_email" 
                                   value="<?php echo esc_attr(get_option('villa_claudia_city_email', '')); ?>" />
                            <p class="description">Email address where guest documents will be sent for city registration.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">SMTP Password</th>
                        <td>
                            <input type="password" style="width: 320px;" 
                                   name="villa_claudia_smtp_password" 
                                   value="<?php echo esc_attr(get_option('villa_claudia_smtp_password')); ?>" />
                            <p class="description">Password for the administration@villa-claudia.eu email account (used for SMTP authentication).</p>
                            <p class="description">If present, values from the server env file override the stored WordPress settings.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
            
            <h3>Integration Information</h3>
            <p>To connect the Villa Claudia Document Upload system, add these settings to your Environment Variables (file):</p>
            <code>
            WORDPRESS_API_URL=<?php echo esc_url(get_rest_url(null, 'villa-claudia/v1')); ?><br>
            WORDPRESS_API_KEY=<?php echo esc_attr($this->get_config_value('villa_claudia_api_key', array('VILLA_CLAUDIA_API_KEY', 'WORDPRESS_API_KEY'), '')); ?>
            </code>
            
            <h3>Testing the API</h3>
            <p>You can test if the API is working correctly by making a request to:</p>
            <code><?php echo esc_url(get_rest_url(null, 'villa-claudia/v1/ping')); ?></code>
            <p>Include the header: <code>x-api-key: <?php echo esc_attr($this->get_config_value('villa_claudia_api_key', array('VILLA_CLAUDIA_API_KEY', 'WORDPRESS_API_KEY'), '')); ?></code></p>
            
            <p>To test with a specific booking ID:</p>
            <code><?php echo esc_url(get_rest_url(null, 'villa-claudia/v1/booking/BOOKING_ID')); ?></code>
            <p>Replace BOOKING_ID with an actual booking ID from MotoPress.</p>
            
            <hr>
            
            <h3>Send Test Email</h3>
            <p>Send a test email with the document upload link for a specific booking:</p>
            
            <?php
            // Display success/error messages
            if (isset($_GET['email_sent']) && $_GET['email_sent'] === 'success') {
                echo '<div class="notice notice-success is-dismissible"><p>Test email sent successfully!</p></div>';
            } elseif (isset($_GET['email_sent']) && $_GET['email_sent'] === 'error') {
                echo '<div class="notice notice-error is-dismissible"><p>Error sending test email. Please check the booking ID and recipient email.</p></div>';
            }
            ?>
            
            <form method="post" action="">
                <?php wp_nonce_field('villa_claudia_test_email', 'villa_claudia_test_email_nonce'); ?>
                <input type="hidden" name="action" value="villa_claudia_test_email">
                
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Booking ID</th>
                        <td>
                            <input type="text" name="booking_id" required style="width: 150px;" />
                            <p class="description">Enter the booking ID you want to test.</p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Email Recipient</th>
                        <td>
                            <input type="email" name="recipient_email" required style="width: 320px;" />
                            <p class="description">Enter the email address to receive the test link.</p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Send Test Email', 'secondary'); ?>
            </form>
        </div>
        <?php
    }
    
    public function add_documents_meta_box() {
        add_meta_box(
            'villa_claudia_documents',
            'Guest Documents',
            array($this, 'display_documents_meta_box'),
            'mphb_booking',
            'normal',
            'high'
        );
    }
    
    public function display_documents_meta_box($post) {
        if ($this->active_booking($post->ID)) {
            $token = $this->get_secure_booking_id($post->ID);
            if (is_wp_error($token)) {
                echo '<p>' . esc_html($token->get_error_message()) . '</p>';
            } else {
                $url = 'https://documents.villa-claudia.eu/uploads/' . $token;
                echo '<p><a target="_blank" rel="noreferrer" href="' . esc_url($url) . '">Open guest upload link</a></p>';
            }
        }
        $documents = get_post_meta($post->ID, 'villa_claudia_document');
        
        if (empty($documents)) {
            echo '<p>No documents uploaded for this booking.</p>';
            return;
        }
        
        echo '<table class="widefat" style="width: 100%; border-collapse: collapse; border: 1px solid #4d4d4d;">';
        echo '<thead><tr>';
        echo '<th style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">Traveler</th>';
        echo '<th style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">Document Type</th>';
        echo '<th style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">Document Number</th>';
        echo '<th style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">Filename</th>';
        echo '<th style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">Uploaded</th>';
        echo '</tr></thead>';
        echo '<tbody>';
        
        foreach ($documents as $doc) {
            echo '<tr>';
            echo '<td style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">' . esc_html($doc['traveler_name']) . '</td>';
            echo '<td style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">' . esc_html($doc['document_type']) . '</td>';
            echo '<td style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">' . esc_html($doc['document_number']) . '</td>';
            echo '<td style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">' . esc_html($doc['original_name']) . '</td>';
            echo '<td style="border: 1px solid #4d4d4d; padding: 12px; text-align: left;">' . esc_html($doc['uploaded_at']) . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody></table>';

        // Add Send to City button if documents are verified
        $all_verified = true;
        foreach ($documents as $document) {
            if (($document['status'] ?? 'pending') !== 'verified') {
                $all_verified = false;
                break;
            }
        }

        if ($all_verified && !empty($documents)) {
            echo '<div class="misc-pub-section">';
            echo '<button type="button" class="button button-primary" id="send-to-city" style="width: 100%; margin-top: 10px;">';
            echo 'Send Documents to City';
            echo '</button>';
            echo '</div>';
            
            // Add JavaScript to handle the button click
            echo '<script>
                jQuery(document).ready(function($) {
                    $("#send-to-city").on("click", function() {
                        if (confirm("Are you sure you want to send these documents to the city?")) {
                            var data = {
                                action: "villa_claudia_send_to_city",
                                booking_id: ' . $post->ID . ',
                                nonce: "' . wp_create_nonce('villa_claudia_send_to_city') . '"
                            };
                            
                            $.post(ajaxurl, data, function(response) {
                                if (response.success) {
                                    alert(response.data);
                                } else {
                                    alert("Error: " + response.data);
                                }
                            });
                        }
                    });
                });
            </script>';
        }
    }
    
    public function check_documents_exist($request) {
        $booking_id = $request->get_param('id');
        
        if (empty($booking_id)) {
            return new WP_Error('missing_id', 'Booking ID is required', array('status' => 400));
        }
        
        $has_documents = $this->has_stored_documents($booking_id);
        
        return array(
            'bookingId' => $booking_id,
            'hasDocuments' => $has_documents
        );
    }
    
    /**
     * AJAX handler for viewing a document
     */
    public function ajax_view_document() {
        // Check nonce for security
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'view_document')) {
            wp_die('Security check failed');
        }
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to view this document');
        }
        
        $document_id = isset($_GET['document_id']) ? sanitize_text_field($_GET['document_id']) : '';
        $booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0;
        
        if (empty($document_id) || empty($booking_id)) {
            wp_die('Missing document information');
        }
        
        // Get the document path
        $upload_dir = wp_upload_dir();
        $document_path = $this->document_path($booking_id, $document_id);
        
        if (!$document_path || !file_exists($document_path)) {
            wp_die('Document not found');
        }
        
        // Get file info
        $file_info = pathinfo($document_path);
        $file_extension = strtolower($file_info['extension']);
        
        // Set content type based on file extension
        $content_types = array(
            'pdf' => 'application/pdf',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png'
        );
        
        $content_type = isset($content_types[$file_extension]) ? $content_types[$file_extension] : 'application/octet-stream';
        
        // Output appropriate headers
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        header('Content-Type: ' . $content_type);
        header('Content-Disposition: inline; filename="' . basename($document_path) . '"');
        header('Content-Length: ' . filesize($document_path));
        
        // Clear any previous output
        ob_clean();
        flush();
        
        // Output the file
        readfile($document_path);
        exit;
    }
    
    // Simple ping endpoint to test API connectivity
    public function ping() {
        return array(
            'status' => 'success',
            'message' => 'API is working correctly',
            'version' => '1.7.6',
            'wordpress' => get_bloginfo('version'),
            'timestamp' => current_time('mysql')
        );
    }
    
    /**
     * Render the Document Uploads admin page
     */
    public function document_uploads_page() {
        // Check if document deletion requested
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['document_id']) && isset($_GET['booking_id'])) {
            $this->delete_document($_GET['booking_id'], $_GET['document_id']);
        }
        
        // Get all bookings with documents
        global $wpdb;
        $bookings_with_docs = $wpdb->get_col(
            "SELECT post_id FROM {$wpdb->postmeta} 
             WHERE meta_key = 'villa_claudia_has_documents' 
             AND meta_value = '1'"
        );
        
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Guest Documents</h1>
            
            <!-- Filters -->
            <div class="tablenav top">
                <div class="alignleft actions">
                    <form method="get">
                        <input type="hidden" name="page" value="document-uploads">
                        <select name="booking_filter" id="booking-filter">
                            <option value="">All Bookings</option>
                            <?php
                            foreach ($bookings_with_docs as $booking_id) {
                                $selected = isset($_GET['booking_filter']) && $_GET['booking_filter'] == $booking_id ? 'selected' : '';
                                echo '<option value="' . esc_attr($booking_id) . '" ' . $selected . '>Booking #' . esc_html($booking_id) . '</option>';
                            }
                            ?>
                        </select>
                        
                        <select name="status_filter" id="status-filter">
                            <option value="">All Statuses</option>
                            <option value="verified" <?php echo isset($_GET['status_filter']) && $_GET['status_filter'] == 'verified' ? 'selected' : ''; ?>>Verified</option>
                            <option value="pending" <?php echo isset($_GET['status_filter']) && $_GET['status_filter'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="rejected" <?php echo isset($_GET['status_filter']) && $_GET['status_filter'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                        
                        <input type="search" id="doc-search" name="s" value="<?php echo isset($_GET['s']) ? esc_attr($_GET['s']) : ''; ?>" placeholder="Search by traveler name...">
                        
                        <input type="submit" id="search-submit" class="button" value="Filter">
                    </form>
                </div>
                <br class="clear">
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th scope="col" class="manage-column">Traveler</th>
                        <th scope="col" class="manage-column">Booking ID</th>
                        <th scope="col" class="manage-column">Document Type</th>
                        <th scope="col" class="manage-column">Document Number</th>
                        <th scope="col" class="manage-column">Uploaded</th>
                        <th scope="col" class="manage-column">Status</th>
                        <th scope="col" class="manage-column">Booking URL</th>
                        <th scope="col" class="manage-column">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($bookings_with_docs as $booking_id) {
                        // Skip if filtering by booking ID and doesn't match
                        if (isset($_GET['booking_filter']) && !empty($_GET['booking_filter']) && $_GET['booking_filter'] != $booking_id) {
                            continue;
                        }
                        
                        $documents = get_post_meta($booking_id, 'villa_claudia_document');
                        
                        if (empty($documents)) {
                            continue;
                        }
                        
                        $booking_post = get_post($booking_id);
                        $guest_email = get_post_meta($booking_id, 'mphb_email', true);
                        
                        foreach ($documents as $document) {
                            // Skip if filtering by status
                            $doc_status = isset($document['status']) ? $document['status'] : 'pending';
                            if (isset($_GET['status_filter']) && !empty($_GET['status_filter']) && $_GET['status_filter'] != $doc_status) {
                                continue;
                            }
                            
                            // Skip if searching and doesn't match
                            if (isset($_GET['s']) && !empty($_GET['s'])) {
                                $search_term = strtolower($_GET['s']);
                                $traveler_name = strtolower($document['traveler_name'] ?? '');
                                
                                if (strpos($traveler_name, $search_term) === false) {
                                    continue;
                                }
                            }
                            
                            $uploaded_at = isset($document['uploaded_at']) ? date('F j, Y', strtotime($document['uploaded_at'])) : 'Unknown';
                            ?>
                            <tr>
                                <td>
                                    <?php echo esc_html($document['traveler_name'] ?? 'Unknown'); ?>
                                    <div class="row-actions">
                                        <span class="email"><?php echo esc_html($guest_email); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <a href="<?php echo admin_url('post.php?post=' . $booking_id . '&action=edit'); ?>">#<?php echo esc_html($booking_id); ?></a>
                                </td>
                                <td><?php echo esc_html($document['document_type'] ?? 'Unknown'); ?></td>
                                <td><?php echo esc_html($document['document_number'] ?? 'Unknown'); ?></td>
                                <td><?php echo esc_html($uploaded_at); ?></td>
                                <td>
                                    <?php
                                    $status_colors = [
                                        'pending' => '#ffc107',
                                        'verified' => '#4CAF50',
                                        'rejected' => '#f44336'
                                    ];
                                    $status_color = isset($status_colors[$doc_status]) ? $status_colors[$doc_status] : '#999';
                                    ?>
                                    <span style="color: <?php echo $status_color; ?>; font-weight: bold;">
                                        <?php echo ucfirst($doc_status); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php 
                                    $secure_id = $this->get_secure_booking_id($booking_id);
                                    if (is_wp_error($secure_id)) {
                                        echo esc_html($secure_id->get_error_message());
                                    } else {
                                    
                                    // Use the documents subdomain for the booking URL
                                    $upload_url = 'https://documents.villa-claudia.eu/uploads/' . $secure_id;
                                    echo '<a href="#" onclick="navigator.clipboard.writeText(\'' . $upload_url . '\');alert(\'URL copied!\');return false;" title="Click to copy">' . $upload_url . '</a>';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <a href="<?php echo admin_url('admin-ajax.php?action=villa_claudia_view_document&document_id=' . urlencode($document['filename']) . '&booking_id=' . $booking_id . '&_wpnonce=' . wp_create_nonce('view_document')); ?>" class="button button-small" target="_blank">View</a>
                                    
                                    <a href="<?php echo add_query_arg(['action' => 'update_status', 'document_id' => $document['filename'], 'booking_id' => $booking_id, 'status' => 'verified', '_wpnonce' => wp_create_nonce('update_document_status')]); ?>" class="button button-small" style="background-color:#4CAF50;color:white;border-color:#4CAF50;">Verify</a>
                                    
                                    <a href="<?php echo add_query_arg(['action' => 'update_status', 'document_id' => $document['filename'], 'booking_id' => $booking_id, 'status' => 'rejected', '_wpnonce' => wp_create_nonce('update_document_status')]); ?>" class="button button-small" style="background-color:#f44336;color:white;border-color:#f44336;">Reject</a>
                                    
                                    <a href="<?php echo add_query_arg(['action' => 'delete', 'document_id' => $document['filename'], 'booking_id' => $booking_id, '_wpnonce' => wp_create_nonce('delete_document')]); ?>" class="button button-small" style="color:red;" onclick="return confirm('Are you sure you want to delete this document?');">Delete</a>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * Delete a document
     */
    private function delete_document($booking_id, $document_id) {
        // Verify nonce
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'delete_document')) {
            wp_die('Security check failed');
        }
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to delete documents');
        }
        
        $result = $this->remove_stored_document($booking_id, $document_id);
        if (is_wp_error($result)) {
            wp_die(esc_html($result->get_error_message()), '', array('response' => $result->get_error_data()['status']));
        }

        // Redirect back to the document list
        wp_redirect(admin_url('admin.php?page=document-uploads'));
        exit;
    }
    
    /**
     * Handle document status updates
     */
    public function handle_document_status_update() {
        if (isset($_GET['action']) && $_GET['action'] === 'update_status' && 
            isset($_GET['document_id']) && isset($_GET['booking_id']) && isset($_GET['status'])) {
            
            // Verify nonce
            if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'update_document_status')) {
                wp_die('Security check failed');
            }
            
            // Check if user has permission
            if (!current_user_can('manage_options')) {
                wp_die('You do not have permission to update document status');
            }
            
            $booking_id = intval($_GET['booking_id']);
            $document_id = sanitize_text_field($_GET['document_id']);
            $new_status = sanitize_text_field($_GET['status']);
            
            // Validate status
            if (!in_array($new_status, ['pending', 'verified', 'rejected'])) {
                wp_die('Invalid status');
            }
            
            $documents = get_post_meta($booking_id, 'villa_claudia_document');
            $updated = false;
            
            foreach ($documents as $index => $document) {
                if ($document['filename'] === $document_id) {
                    // Update the status
                    $document['status'] = $new_status;
                    // Update in database
                    if ($document !== $documents[$index] && !update_post_meta($booking_id, 'villa_claudia_document', $document, $documents[$index])) {
                        wp_die('The document changed or its status could not be saved. Refresh and retry.', '', array('response' => 409));
                    }
                    $updated = true;
                    break;
                }
            }
            
            if ($updated) {
                // Add admin notice
                add_action('admin_notices', function() use ($new_status) {
                    echo '<div class="notice notice-success is-dismissible"><p>Document status updated to ' . ucfirst($new_status) . '.</p></div>';
                });
            }
            
            // Redirect back to the document list
            wp_redirect(admin_url('admin.php?page=document-uploads'));
            exit;
        }
    }
    
    /**
     * Get booking data by secure ID
     */
    /**
     * Handle sending test email with document upload link
     */
    public function handle_test_email() {
        if (isset($_POST['action']) && $_POST['action'] === 'villa_claudia_test_email') {
            // Verify nonce
            if (!isset($_POST['villa_claudia_test_email_nonce']) || !wp_verify_nonce($_POST['villa_claudia_test_email_nonce'], 'villa_claudia_test_email')) {
                wp_die('Security check failed');
            }
            
            // Check if user has permission
            if (!current_user_can('manage_options')) {
                wp_die('You do not have permission to send test emails');
            }
            
            $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
            $recipient_email = isset($_POST['recipient_email']) ? sanitize_email($_POST['recipient_email']) : '';
            
            if (empty($booking_id) || empty($recipient_email)) {
                wp_redirect(admin_url('options-general.php?page=villa-claudia-docs&email_sent=error'));
                exit;
            }
            
            // Get booking info
            $booking_post = get_post($booking_id);
            if (!$booking_post || $booking_post->post_type !== 'mphb_booking') {
                wp_redirect(admin_url('options-general.php?page=villa-claudia-docs&email_sent=error'));
                exit;
            }
            
            // Get guest info
            $guest_info = get_post_meta($booking_id, 'mphb_guest_info', true);
            $first_name = '';
            $last_name = '';
            
            if (is_array($guest_info) && isset($guest_info['first_name'])) {
                $first_name = $guest_info['first_name'];
                $last_name = isset($guest_info['last_name']) ? $guest_info['last_name'] : '';
            } else {
                $first_name = get_post_meta($booking_id, 'mphb_first_name', true);
                $last_name = get_post_meta($booking_id, 'mphb_last_name', true);
            }
            
            $guest_name = trim($first_name . ' ' . $last_name);
            if (empty($guest_name)) {
                $guest_name = 'Guest';
            }
            
            // Get secure booking ID and create link
            $secure_id = $this->get_secure_booking_id($booking_id);
            if (is_wp_error($secure_id)) {
                wp_redirect(add_query_arg('email_sent', 'error', wp_get_referer()));
                exit;
            }
            
            // Use the documents subdomain for the booking URL
            $upload_url = 'https://documents.villa-claudia.eu/uploads/' . $secure_id;
            
            // Email content
            $subject = 'Villa Claudia: Your Document Upload Link';
            $message = "Hello $guest_name,\n\n";
            $message .= "Here is your secure link to upload your travel documents for your upcoming stay at Villa Claudia:\n\n";
            $message .= $upload_url . "\n\n";
            $message .= "This link is unique to your booking and ensures your documents are securely attached to your reservation.\n\n";
            $message .= "If you have any questions, please don't hesitate to contact us.\n\n";
            $message .= "Best regards,\nVilla Claudia Team";
            
            $headers = array('Content-Type: text/plain; charset=UTF-8');
            
            // Send email
            $email_sent = wp_mail($recipient_email, $subject, $message, $headers);
            
            if ($email_sent) {
                wp_redirect(admin_url('options-general.php?page=villa-claudia-docs&email_sent=success'));
            } else {
                wp_redirect(admin_url('options-general.php?page=villa-claudia-docs&email_sent=error'));
            }
            exit;
        }
    }

    // Add handler for sending documents to city
    public function handle_send_to_city() {
        check_ajax_referer('villa_claudia_send_to_city', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('You do not have permission to perform this action');
        }
        
        $booking_id = intval($_POST['booking_id']);
        if (!$booking_id) {
            wp_send_json_error('Invalid booking ID');
        }
        
        // Get booking details
        $booking = get_post($booking_id);
        if (!$booking || $booking->post_type !== 'mphb_booking') {
            wp_send_json_error('Booking not found');
        }
        
        // Get guest info
        $guest_info = get_post_meta($booking_id, 'mphb_guest_info', true);
        $first_name = '';
        $last_name = '';
        
        if (is_array($guest_info) && isset($guest_info['first_name'])) {
            $first_name = $guest_info['first_name'];
            $last_name = isset($guest_info['last_name']) ? $guest_info['last_name'] : '';
        } else {
            $first_name = get_post_meta($booking_id, 'mphb_first_name', true);
            $last_name = get_post_meta($booking_id, 'mphb_last_name', true);
        }
        
        $guest_name = trim($first_name . ' ' . $last_name);
        $check_in_date = get_post_meta($booking_id, 'mphb_check_in_date', true);
        $check_out_date = get_post_meta($booking_id, 'mphb_check_out_date', true);
        
        // Calculate number of nights
        $nights = 0;
        if (!empty($check_in_date) && !empty($check_out_date)) {
            $check_in = new DateTime($check_in_date);
            $check_out = new DateTime($check_out_date);
            $interval = $check_in->diff($check_out);
            $nights = $interval->days;
        }
        
        // Get documents
        $documents = get_post_meta($booking_id, 'villa_claudia_document');
        if (empty($documents)) {
            wp_send_json_error('No documents found for this booking');
        }
        
        // Group documents by traveler
        $travelers = array();
        foreach ($documents as $document) {
            if ($document['status'] === 'verified') {
                $traveler_name = $document['traveler_name'];
                if (!isset($travelers[$traveler_name])) {
                    $travelers[$traveler_name] = array(
                        'name' => $traveler_name,
                        'documents' => array()
                    );
                }
                $travelers[$traveler_name]['documents'][] = $document;
            }
        }
        
        if (empty($travelers)) {
            wp_send_json_error('No verified documents found for this booking');
        }
        
        // Prepare email content
        $subject = sprintf('Guest Documents - %s - Check-in: %s', $guest_name, $check_in_date);
        
        // Create simple pre-formatted text email for maximum Outlook compatibility
        $message = "Dear City Administration,\r\n\r\n";
        $message .= "Please find attached the documents for the following guests:\r\n\r\n";
        $message .= "GUEST DOCUMENTS INFORMATION:\r\n";
        
        // Add each guest's information in a simple pre-formatted way
        foreach ($travelers as $traveler) {
            foreach ($traveler['documents'] as $document) {
                if ($document['status'] === 'verified') {
                    $message .= "---------------------------------------------\r\n";
                    $message .= "Guest: " . esc_html($traveler['name']) . "\r\n";
                    $message .= "Document Type: " . esc_html(ucfirst($document['document_type'])) . "\r\n";
                    $message .= "Document Number: " . esc_html($document['document_number']) . "\r\n";
                }
            }
        }
        
        $message .= "---------------------------------------------\r\n\r\n";
        $message .= "Check-in Date: " . esc_html($check_in_date) . "\r\n";
        $message .= "Check-out Date: " . esc_html($check_out_date) . "\r\n";
        $message .= "Number of Nights: " . esc_html($nights) . "\r\n";
        $message .= "Booking ID: " . esc_html($booking_id) . "\r\n\r\n";
        $message .= "Best regards,\r\nVilla Claudia";
        
        $city_email = $this->get_config_value(
            'villa_claudia_city_email',
            array('VILLA_CLAUDIA_CITY_EMAIL'),
            ''
        );
        $result = $this->send_verified_documents($booking_id, $city_email, $subject, $message);
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        wp_send_json_success($result['recorded']
            ? 'Documents sent successfully'
            : 'Email accepted, but the sent status could not be saved. Contact the administrator before resending.');
    }

    // Add new method for the Send to City page
    public function send_to_city_page() {
        // Check if form was submitted
        if (isset($_POST['send_to_city_submit'])) {
            check_admin_referer('villa_claudia_send_to_city_form');
            
            $booking_id = intval($_POST['booking_id']);
            $recipient_email = sanitize_email($_POST['recipient_email']);
            $subject = sanitize_text_field($_POST['email_subject']);
            $message = sanitize_textarea_field($_POST['email_message']);
            
            $result = $this->send_verified_documents($booking_id, $recipient_email, $subject, $message);
            if (is_wp_error($result)) {
                echo '<div class="notice notice-error"><p>' . esc_html($result->get_error_message()) . '</p></div>';
            } else {
                echo '<div class="notice notice-success"><p>' . esc_html($result['recorded']
                    ? 'Documents sent successfully!'
                    : 'Email accepted, but the sent status could not be saved. Contact the administrator before resending.') . '</p></div>';
            }
        }

        // Get all bookings with documents
        global $wpdb;
        $bookings_with_docs = $wpdb->get_col(
            "SELECT post_id FROM {$wpdb->postmeta} 
             WHERE meta_key = 'villa_claudia_has_documents' 
             AND meta_value = '1'"
        );
        
        ?>
        <div class="wrap">
            <h1>Send Documents to City</h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('villa_claudia_send_to_city_form'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="booking_id">Select Booking</label></th>
                        <td>
                            <select name="booking_id" id="booking_id" required>
                                <option value="">Select a booking...</option>
                                <?php
                                foreach ($bookings_with_docs as $booking_id) {
                                    $guest_info = get_post_meta($booking_id, 'mphb_guest_info', true);
                                    $first_name = is_array($guest_info) && isset($guest_info['first_name']) ? $guest_info['first_name'] : get_post_meta($booking_id, 'mphb_first_name', true);
                                    $last_name = is_array($guest_info) && isset($guest_info['last_name']) ? $guest_info['last_name'] : get_post_meta($booking_id, 'mphb_last_name', true);
                                    $check_in_date = get_post_meta($booking_id, 'mphb_check_in_date', true);
                                    
                                    printf(
                                        '<option value="%d">Booking #%d - %s %s (Check-in: %s)</option>',
                                        $booking_id,
                                        $booking_id,
                                        esc_html($first_name),
                                        esc_html($last_name),
                                        esc_html($check_in_date)
                                    );
                                }
                                ?>
                            </select>
                            <p class="description">Select the booking whose documents you want to send.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="recipient_email">Recipient Email</label></th>
                        <td>
                            <input type="email" name="recipient_email" id="recipient_email" class="regular-text" 
                                   value="<?php echo esc_attr($this->get_config_value('villa_claudia_city_email', array('VILLA_CLAUDIA_CITY_EMAIL'), '')); ?>" required>
                            <p class="description">Enter the email address where the documents should be sent.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="email_subject">Email Subject</label></th>
                        <td>
                            <input type="text" name="email_subject" id="email_subject" class="regular-text" 
                                   placeholder="Guest Documents - [Guest Name] - Check-in: [Date]" required>
                            <p class="description">Enter the subject line for the email.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="email_message">Email Message</label></th>
                        <td>
                            <textarea name="email_message" id="email_message" class="large-text" rows="15" required>Dear City Administration,

Please find attached the documents for the following guests:

GUEST DOCUMENTS INFORMATION:
[Guest Documents Table Rows]
---------------------------------------------

Check-in Date: [Check-in Date]
Check-out Date: [Check-out Date]
Number of Nights: [Number of Nights]
Booking ID: [Booking ID]

Best regards,
Villa Claudia</textarea>
                            <p class="description">Enter the message body for the email. Plain text format is recommended for Outlook compatibility.</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="send_to_city_submit" class="button button-primary" value="Send Documents">
                </p>
            </form>
            
            <script>
            jQuery(document).ready(function($) {
                var requestVersion = 0;
                $('#booking_id').on('change', function() {
                    var version = ++requestVersion;
                    var sendButton = $('input[name=send_to_city_submit]').prop('disabled', true);
                    $('#email_subject, #email_message').val('');
                    var bookingId = $(this).val();
                    if (bookingId) {
                        $.post(ajaxurl, {
                            action: 'villa_claudia_get_booking_docs',
                            booking_id: bookingId,
                            nonce: '<?php echo wp_create_nonce("villa_claudia_get_docs"); ?>'
                        }, function(response) {
                            if (version !== requestVersion || bookingId !== $('#booking_id').val()) { return; }
                            if (response.success) {
                                var guestName = $('option:selected', '#booking_id').text().split(' - ')[1];
                                var bookingInfo = $('option:selected', '#booking_id').text().split('Check-in: ')[1].replace(')', '');
                                var checkInDate = bookingInfo;
                                var checkOutDate = '';
                                var nights = 0;
                                
                                // Get check-out date and calculate nights
                                $.post(ajaxurl, {
                                    action: 'villa_claudia_get_booking_dates',
                                    booking_id: bookingId,
                                    nonce: '<?php echo wp_create_nonce("villa_claudia_get_dates"); ?>'
                                }, function(datesResponse) {
                                    if (version !== requestVersion || bookingId !== $('#booking_id').val()) { return; }
                                    if (datesResponse.success) {
                                        checkInDate = datesResponse.data.check_in_date;
                                        checkOutDate = datesResponse.data.check_out_date;
                                        nights = datesResponse.data.nights;
                                        
                                        // Update subject
                                        $('#email_subject').val('Guest Documents - ' + guestName + ' - Check-in: ' + checkInDate);
                                        
                                        // Create plain text rows for documents
                                        var tableRows = '';
                                        response.data.forEach(function(doc) {
                                            if (doc.status === 'verified') {
                                                tableRows += "---------------------------------------------\n";
                                                tableRows += "Guest: " + doc.traveler_name + "\n";
                                                tableRows += "Document Type: " + doc.document_type + "\n";
                                                tableRows += "Document Number: " + doc.document_number + "\n";
                                            }
                                        });
                                        
                                        // Create plain text email template
                                        var messageTemplate = `Dear City Administration,

Please find attached the documents for the following guests:

GUEST DOCUMENTS INFORMATION:
${tableRows}---------------------------------------------

Check-in Date: ${checkInDate}
Check-out Date: ${checkOutDate}
Number of Nights: ${nights}
Booking ID: ${bookingId}

Best regards,
Villa Claudia`;
                                        
                                        $('#email_message').val(messageTemplate);
                                        sendButton.prop('disabled', false);
                                    }
                                });
                            }
                        });
                    }
                });
            });
            </script>
        </div>
        <?php
    }

    // Add this new method to the class
    public function ajax_get_booking_docs() {
        check_ajax_referer('villa_claudia_get_docs', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }
        
        $booking_id = intval($_POST['booking_id']);
        $documents = get_post_meta($booking_id, 'villa_claudia_document');
        
        wp_send_json_success($documents);
    }

    // Add new method for SMTP configuration
    public function configure_smtp($phpmailer) {
        $phpmailer->isSMTP();
        $phpmailer->Host = 'smtp.hostinger.com';
        $phpmailer->SMTPAuth = true;
        $phpmailer->Port = 465;
        $phpmailer->SMTPSecure = 'ssl';
        $phpmailer->Username = 'administration@villa-claudia.eu';
        $phpmailer->Password = $this->get_config_value(
            'villa_claudia_smtp_password',
            array('VILLA_CLAUDIA_SMTP_PASSWORD', 'SMTP_PASSWORD', 'EMAIL_PASS'),
            ''
        );
        $phpmailer->From = 'administration@villa-claudia.eu';
        $phpmailer->FromName = 'Villa Claudia';
    }

    // Add new method for getting booking dates and calculating nights
    public function ajax_get_booking_dates() {
        check_ajax_referer('villa_claudia_get_dates', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }
        
        $booking_id = intval($_POST['booking_id']);
        if (!$booking_id) {
            wp_send_json_error('Invalid booking ID');
        }
        
        $check_in_date = get_post_meta($booking_id, 'mphb_check_in_date', true);
        $check_out_date = get_post_meta($booking_id, 'mphb_check_out_date', true);
        
        // Calculate number of nights
        $nights = 0;
        if (!empty($check_in_date) && !empty($check_out_date)) {
            $check_in = new DateTime($check_in_date);
            $check_out = new DateTime($check_out_date);
            $interval = $check_in->diff($check_out);
            $nights = $interval->days;
        }
        
        wp_send_json_success(array(
            'check_in_date' => $check_in_date,
            'check_out_date' => $check_out_date,
            'nights' => $nights
        ));
    }
}

// Initialize the plugin
$villa_claudia_docs = new Villa_Claudia_Docs(); 
